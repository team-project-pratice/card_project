
import pandas as pd
import numpy as np

def preprocess_vip_card(card_df: pd.DataFrame, card2_df: pd.DataFrame) -> pd.DataFrame:
    # 병합
    df = pd.merge(card_df, card2_df, on='발급회원번호', how='inner')
    df = df.drop(columns=['발급회원번호'])

    # VIP 등급 처리
    df['VIP등급코드'] = df['VIP등급코드'].str.replace('_', '0').astype(int)
    df = df[~df['VIP등급코드'].isin([4, 5])].copy()
    df['VIP등급코드'] = df['VIP등급코드'].replace({7: 1, 6: 2})

    # 연령 전처리 (강화 버전)
    def clean_age(age_str):
        try:
            if pd.isna(age_str): return np.nan
            if isinstance(age_str, (int, float)): return int(age_str)
            cleaned = age_str.replace('대', '').replace('이상', '').replace('미만', '').strip()
            return int(cleaned) if cleaned.isdigit() else np.nan
        except Exception:
            return np.nan

    df['연령'] = df['연령'].apply(clean_age)
    df['연령'] = df['연령'].fillna(-1).astype(int)

    # 파생변수 생성
    df['이용금액_1개월'] = df[['이용금액_체크_B0M', '이용금액_일시불_B0M', '이용금액_할부_B0M']].sum(axis=1)
    df['이용금액_3개월'] = df[['이용금액_체크_R3M', '이용금액_일시불_R3M', '이용금액_할부_R3M']].sum(axis=1)
    df['이용금액_6개월'] = df[['이용금액_체크_R6M', '이용금액_일시불_R6M', '이용금액_할부_R6M']].sum(axis=1)
    df['이용금액_12개월'] = df[['이용금액_체크_R12M', '이용금액_일시불_R12M', '이용금액_할부_R12M']].sum(axis=1)
    df['이용건수_3개월'] = df[['이용건수_체크_R3M', '이용건수_일시불_R3M', '이용건수_할부_R3M']].sum(axis=1)
    df['이용건수_6개월'] = df[['이용건수_체크_R6M', '이용건수_일시불_R6M', '이용건수_할부_R6M']].sum(axis=1)
    df['이용개월수_3개월'] = df[['이용개월수_체크_R3M', '이용개월수_일시불_R3M', '이용개월수_할부_R3M']].sum(axis=1)
    df['이용개월수_12개월'] = df[['이용개월수_체크_R12M', '이용개월수_일시불_R12M', '이용개월수_할부_R12M']].sum(axis=1)
    df['최근_이용금액_비중'] = df['이용금액_1개월'] / (df['이용금액_12개월'] + 1)
    df['이용금액_증감률'] = (df['이용금액_3개월'] - df['이용금액_6개월']) / (df['이용금액_6개월'] + 1)
    df['활동성_3개월'] = df['이용금액_3개월'] / (df['이용개월수_3개월'] + 1)
    df['활동성_12개월'] = df['이용금액_12개월'] / (df['이용개월수_12개월'] + 1)

    # 드랍 컬럼
    cols_to_drop = [
        '이용건수_일시불_B0M', '이용건수_체크_B0M', '이용건수_할부_B0M',
        '최종이용일자_일시불', '최종이용일자_체크', '최종이용일자_할부',
        '이용후경과월_일시불', '이용후경과월_체크', '이용후경과월_할부',
        '이용금액_R3M_신용체크', '이용금액_R3M_신용',
        '회원여부_이용가능', '회원여부_이용가능_CA', '회원여부_이용가능_카드론',
        '입회경과개월수_신용', '탈회횟수_누적', '최종탈회후경과월',
        '탈회횟수_발급6개월이내', '탈회횟수_발급1년이내',
        '마케팅동의여부', '최대이용금액_일시불_R12M',
        '최대이용금액_체크_R12M', '최대이용금액_할부_R12M',
        '이용개월수_일시불_R6M', '이용개월수_할부_R6M', '이용개월수_체크_R6M'
    ]
    df = df.drop(columns=cols_to_drop, inplace=False)

    return df
